(function () {
    var getLatestMsg = function () {
        jQuery.ajax({
            url: "http://mgr.calculatedfun.com/json/data/getLatestMsg.shtml",
            type: "post",
            dataType: "json",
            success: function (data) {
                if (data == null) {
                    return;
                }
                for (var a in data) {
                    if (data[a] == null) {
                        continue;
                    }
                    var arr;
                    if (!datasetMap[a]) {
                        arr = [];
                    } else {
                        arr = datasetMap[a];
                    }
                    if (data[a].x != null && data[a].y != null) {
                        arr.push([data[a].x, data[a].y]);
                    }
                    datasetMap[a] = arr;

                    var arrDeta;
                    if (!datasetDetaMap[a]) {
                        arrDeta = [];
                    } else {
                        arrDeta = datasetDetaMap[a];
                    }
                    if (data[a].x != null && data[a].y != null) {
                        if (a > 3 && data[a].x == 0 && data[a].y == 0) {
                            arrDeta.push(testInitPoint[a]);;
                        } else {
                            arrDeta.push([data[a].x, data[a].y]);
                        }
                    }
                    datasetDetaMap[a] = arrDeta;
                }
            },
            complete: function (data) {
            },
            error: function (e) {
                console.log("数据中断，稍后重试！");
            },
            timeout: 5000
        });
    };

    var getTaskPathData = function () {
        jQuery.ajax({
            url: "http://mgr.calculatedfun.com/json/data/getTaskPathData.shtml?received=" + receivedTaskData,
            type: "post",
            dataType: "json",
            success: function (data) {
                if (data.code) {
                    if (data.code == -2) {
                        datasetMap[9999] = [];
                        receivedTaskData = "false";
                        return;
                    } else if (data.code == -1) {
                        return;
                    }
                }
                if (data == null) {
                    return;
                }
                for (var a in data) {
                    var arr;
                    if (!datasetMap[9999]) {
                        arr = [];
                    } else {
                        arr = datasetMap[9999];
                    }
                    for (var v in data[a]) {
                        if (data[a][v].x != null && data[a][v].y != null) {
                            arr.push([data[a][v].x, data[a][v].y]);
                        }
                        datasetMap[9999] = arr;
                    }
                }
                receivedTaskData = "true";
            },
            complete: function (data) {
            },
            error: function (e) {
                console.log("数据中断，稍后重试！");
            },
            timeout: 5000
        });
    };

    // var getClashArea = function () {
    //     jQuery.ajax({
    //         url: "/json/data/getClashArea.shtml",
    //         type: "post",
    //         dataType: "json",
    //         success: function (data) {
    //             if (data == null) {
    //                 return;
    //             }
    //             clashArea = data;
    //         },
    //         timeout: 5000
    //     });
    // };

    setInterval(getLatestMsg, 1000);
    //setInterval(getTaskPathData, 2000);
    // setInterval(getClashArea, 2000);

})(jQuery);
