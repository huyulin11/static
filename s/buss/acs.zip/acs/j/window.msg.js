$(function () {
    var doWork = function () {
        jQuery.ajax({
            url: "/de/acs/wms/temp/windows.shtml",
            type: "post",
            dataType: "json",
            success: function (data) {
                $("div#windowsDiv").html("");
                var tables = "";
                for (var a of data) {
                    var trs = "";
                    if (!a.info) { continue; }
                    for (var tt of a.info) {
                        trs = "<tr><td>" + (tt == 0 ? "空" : "<font style='color:red;'>有</font>") + "</td></tr>" + trs;
                    }
                    trs = "<td><table>" + trs + "</table><td>";
                    tables += trs;
                }
                $("div#windowsDiv").append("<table><td>" + tables + "</tr></table>");
                resizeTable();
            }
        });
    }

    setInterval(() => {
        doWork();
    }, 2000);
});
