var renderOne = function (numOfRow, agvinfo, agvDiv) {
    var currentTable = "table.agv[data-area='" + agvinfo.environment + "']";
    if ($(currentTable).length <= 0) {
        agvDiv.append("<hr class='withBorder'/>" +
            "<table class='agv' data-area='" + agvinfo.environment + "'><caption style='color:black'>"
            + (agvinfo.environment == 1 ? "AGV列表" : "二楼仓库AGV列表") + "↓" + "</caption></table>");
    }
    var moveStatusVal = "";
    if (agvinfo.movestatus == "CONTINUE") {
        moveStatusVal += "启";
    } else if (agvinfo.movestatus == "PAUSE_SYS") {
        moveStatusVal += "自停";
    } else if (agvinfo.movestatus == "PAUSE_ERR") {
        moveStatusVal += "错误停车";
    } else if (agvinfo.movestatus == "PAUSE_USER") {
        moveStatusVal += "手停";
    }

    var siteStatusVal = "";
    if (agvinfo.sitestatus == "INIT") {
        siteStatusVal += "初始站点";
    } else if (agvinfo.sitestatus == "MOVING") {
        siteStatusVal += "行驶中";
    } else if (agvinfo.sitestatus == "WINDOW_GET") {
        siteStatusVal += "窗口获取档案";
    } else if (agvinfo.sitestatus == "ALLOC_STOCK") {
        siteStatusVal += "货位放货";
    } else if (agvinfo.sitestatus == "WINDOW_STOCK") {
        siteStatusVal += "窗口放货";
    } else if (agvinfo.sitestatus == "ALLOC_SCAN") {
        siteStatusVal += "窗口扫描";
    } else if (agvinfo.sitestatus == "ALLOC_GET") {
        siteStatusVal += "货位取货";
    } else if (agvinfo.sitestatus == "CHARGING") {
        siteStatusVal += "正在充电";
    }

    var taskStatusVal = "";
    var colorStyle = "";
    if (agvinfo.taskstatus == "FREE") {
        taskStatusVal += "空闲";
    } else if (agvinfo.taskstatus == "RECEIPT") {
        taskStatusVal += "入库";
        colorStyle = "style='background-color:gray;'";
    } else if (agvinfo.taskstatus == "SHIPMENT") {
        taskStatusVal += "出库";
        colorStyle = "style='background-color:gray;'";
    } else if (agvinfo.taskstatus == "INVENTORY") {
        taskStatusVal += "盘点";
        colorStyle = "style='background-color:gray;'";
    } else if (agvinfo.taskstatus == "GOTO_CHARGE" || agvinfo.taskstatus == "BACK_CHARGE") {
        var chargeInfo = "";
        if (agvinfo.chargeid) {
            if (agvinfo.chargeid == 13) {
                chargeInfo = "-1号充电站"
            } else if (agvinfo.chargeid == 14) {
                chargeInfo = "-2号充电站";
            } else if (agvinfo.chargeid == 0) {
                chargeInfo = "-暂未找到合适充电站";
            }
        } else if (agvinfo.chargeid == 0) {
            chargeInfo = "-暂未找到合适充电站";
        }
        if (agvinfo.taskstatus == "GOTO_CHARGE") {
            taskStatusVal += "前往充电" + chargeInfo;
        } else {
            taskStatusVal += "停止充电返回" + chargeInfo;
        }
        colorStyle = "style='background-color:red;'";
    } else {
        taskStatusVal += agvinfo.taskstatus;
    }

    var tmpStr = "<td class='agv'>" + "<div>"
        + "<button id='" + agvinfo.id + "'" + colorStyle + ">" + "<table cellspacing='0px' cellspadding='2px'>"
        + "<tr><td>" + agvinfo.id + "号AGV" + "</td><td>" + "行驶状态:" + moveStatusVal + "</td></tr>"
        + "<tr><td>" + "站点状态:" + siteStatusVal + "</td><td>" + "当前站点:" + (agvinfo.currentsite ? agvinfo.currentsite : "") + "</td></tr>"
        + "<tr><td>" + "当前电压:" + (agvinfo.battery ? agvinfo.battery : "") + "</td><td>" + "当前速度(%):" + (agvinfo.speed ? agvinfo.speed : "") + "</td></tr>"
        + "<tr><td colspan='2'>" + "任务状态:" + taskStatusVal + (agvinfo.taskid ? "<br/>" + agvinfo.taskid : "") + "</td></tr>"
        + "<tr><td colspan='2'>" + "AGV反馈状态:" + (agvinfo.agvstatus ? agvinfo.agvstatus : "") + "</td></tr>"
        + "<tr><td colspan='2'>" + "硬件状态:" + (agvinfo.plcstatus ? agvinfo.plcstatus : "正常") + "</td></tr>"
        + "</table>" + "</button></div></td>";

    if ($(currentTable).find("tr.agvTr:last").find("td.agv").length >= numOfRow || $(currentTable).find("tr.agvTr:last").length == 0) {
        $(currentTable).append("<tr class='agvTr'></tr>");
    }
    $(currentTable).find("tr.agvTr:last").append(tmpStr);
}