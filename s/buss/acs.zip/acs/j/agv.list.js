(function () {
    var reloadFlag = 0;
    var intervalVal;

    var agvDiv = function () {
        if ($("div#agvDiv").length == 0) {
            $("body").append("<div id='agvDiv'></div>");
        }
        return $("div#agvDiv");
    }

    var getAGVList = function () {
        jQuery.ajax({
            url: "/getAGVListSop.shtml",
            type: "post",
            dataType: "json",
            error: function (e) {
                layer.msg("数据中断，请刷新界面或重新登录！");
            },
            complete: function () {
                setTimeout(function () {
                    overlay.hide();
                }, 1000);
            },
            timeout: 6000,
            success: whenSuccess
        });
    }

    var whenSuccess = function (data) {
        overlay.show();
        doWhenSuccess(data);
    }

    var doWhenSuccess = function (data) {
        reloadFlag = 0;
        agvDiv().html("");
        var dl = data.length;
        var numOfRow = dl >= 2 ? 2 : dl;

        $.each(data, function (n, agvinfo) {
            renderOne(numOfRow, agvinfo, agvDiv());
        });
        resizeTable();
    }

    var openAGVMGR = function (tmpAgvId, layerName) {
        {
            agvId = tmpAgvId;
            $("div#oneAgv").load("/s/buss/acs/h/agv.one.agv.html");
            return;
        }
        if (tmpAgvId == 1) {
            layerOpen({ content: '/s/buss/acs/h/agv.one.html?agvId=' + tmpAgvId, title: layerName, offset: 'rb' });
        } else {
            layerOpen({ content: '/s/buss/acs/h/agv.one.html?agvId=' + tmpAgvId, title: layerName, offset: 'rb' });
        }
    }

    var init = function () {
        getAGVList();
        intervalVal = setInterval(getAGVList, 3000);

        agvDiv().delegate("button", "click", function () {
            openAGVMGR($(this).attr("id"), $(this).html());
        });
    }

    init();
})(jQuery);
