var areaInfoInitOver = 1;//不包含WMS的项目初始值为1,否则为0
var timeLength = 1200;
var updateWidth = function () {
    $("table").each(function () {
        var tds = $(this).find("tr:first").find("td");
        tds.css("width", 100 / (tds.length) + "%");
    });
}
var updateHeight = function () {
    var height = 60;
    $(".area td button").each(function () {
        if ($(this).height() > height) {
            height = $(this).height();
        }
    });
    $(".area td button").css("height", height + "px");
}
var updateMgrPosition = function () {
    $("#fadeIndex").hide();
    return;
    if ($("#agvsMgr").height() > window.innerHeight * 0.8) {
        $("#msg").css("position", "relative");
    } else {
        $("#msg").css("position", "fixed");
    }
}

var intervalVal = setInterval(function () {
    if (areaInfoInitOver == 1) {
        updateWidth();
        areaInfoInitOver = 2;
    } else if (areaInfoInitOver == 2) {
        updateHeight();
        areaInfoInitOver = 3;
    } else if (areaInfoInitOver == 3) {
        updateMgrPosition();
        clearInterval(intervalVal);
    }
}, 300);