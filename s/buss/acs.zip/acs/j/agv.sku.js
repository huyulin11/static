$(function () {
    sku = new Object();

    var allSkuInfo;
    var allSkuType;

    sku.select = function (json) {
        var tmpOpStr = "";
        var skuId = json.skuId, allowedskutype = json.allowedskutype,
            allowedskuid = json.allowedskuid, environment = json.environment;
        $.each(sku.getSkuInfo(), function (sn, thisSkuInfo) {
            if (allowedskutype && allowedskutype != 0 && allowedskuid && allowedskuid != 0) {
                if (!(thisSkuInfo.type == allowedskutype || thisSkuInfo.skuId == allowedskuid)) {
                    return;
                }
            } else {
                if (allowedskutype && allowedskutype != 0 && thisSkuInfo.type != allowedskutype) {
                    return;
                }
                if (allowedskuid && allowedskuid != 0 && thisSkuInfo.skuId != allowedskuid) {
                    return;
                }
            }
            if (environment && environment != 0 && thisSkuInfo.environment != environment) {
                return;
            }
            tmpOpStr = tmpOpStr + "<option " + "value='" + thisSkuInfo.skuId + "' "
                + (thisSkuInfo.skuId == skuId ? "selected='selected'" : "") + ">"
                + thisSkuInfo.skuName + "</option>";
        });
        return "<select>" + tmpOpStr + "</select>";
    }

    sku.value = function (skuId) {
        var tmpOpStr = "";
        $.each(sku.getSkuInfo(), function (sn, thisSkuInfo) {
            if (thisSkuInfo.id == skuId) { tmpOpStr = thisSkuInfo.name; return; }
        });
        return tmpOpStr;
    }

    sku.typevalue = function (skuTypeId) {
        var tmpOpStr = "";
        $.each(sku.getSkuType(), function (sn, thisSkuType) {
            if (thisSkuType.id == skuTypeId) { tmpOpStr = thisSkuType.name; return; }
        });
        return tmpOpStr;
    }

    sku.getSkuInfo = function () {
        if (!allSkuInfo) {
            initData();
        } return allSkuInfo;
    }


    sku.getSkuType = function () {
        if (!allSkuType) {
            initData();
        } return allSkuType;
    }

    initData = function () {
        jQuery.ajax({
            url: "/json/wms/getSkuInfo.shtml",
            type: "post",
            dataType: "json",
            async: false,
            success: function (data) {
                allSkuInfo = data.skuInfo;
                allSkuType = data.skuType;
            }
        });
    }

    sku.changeSku = function (lapId, skuId) {
        jQuery.ajax({
            url: "/json/wms/changeSku.shtml?lapId=" + lapId + "&skuId=" + skuId,
            type: "post",
            dataType: "json",
            success: function (data) {
                if (data > 0) {
                    getSkuInfo();
                    alert("更新成功");
                }
            }
        });
    }
});
