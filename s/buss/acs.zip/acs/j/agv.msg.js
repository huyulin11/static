(function () {
    var lastMsgMap = new Map();
    var msgLen = 0;
    var addMsg = function (msg, level, agvId) {

        var w = "";
        if (agvId) {
            if (agvId > 0) {
                w = "<span class='redFont tips'>" + agvId + "号AGV：</span>";
            } else {
                w = "<span class='redFont tips'>系统消息：</span>";
            }
        } else {
            agvId = 0;
        }

        var tip = "div#tips" + agvId;

        if ($(tip).length <= 0) {
            $("div#tipsOper").append("<div id='tips" + agvId + "'>" + w + "</div>");
        }

        if (msg != "" && (lastMsgMap.get(agvId) == null || lastMsgMap.get(agvId) != msg)) {
            lastMsgMap.set(agvId, msg);
            var fontClass = (level == 1 ? "redFont" : (level == 2 ? "blueFont" : "redFont"));
            if ($(tip).find("span").length > 2) {
                var rm = $(tip).find("span").length - 2;
                $(tip).find("span:lt(" + rm + "):gt(0)").remove();
            }

            $(tip).append("<span " + "class='tips " + fontClass + "' data-id='" + msgLen + "'" + ">**" + msg + "**</span>");
            $(tip).find("span[data-id!=" + (msgLen++) + "]:gt(0)").addClass("greyFont");
        }
    }

    var agvsinfo = function () {
        jQuery.ajax({
            url: "/agvsinfo.shtml",
            type: "post",
            dataType: "json",
            success: function (data) {
                $.each(data, function (n, value) {
                    addMsg(value.systemWarning, 1, n);

                    if (n > 0) {
                        if (value.currentTask != null && value.currentTask.length > 0) {
                            var msg = (value.currentTask[0].opflag == "Over" ? "执行结束：" : "正在执行：") + value.currentTask[0].taskText;
                            addMsg(msg, 3, n);
                        }
                    } else {
                        $("div#stopPIDiv").html("");
                        $("div#stopPIDiv").append(
                            "<button id='stopPI' data-open=" + (value.agvsOpenPI == 1 ? "true" : "false")
                            + ">" + (value.agvsOpenPI == 1 ? "关闭交通管制" : "开启交通管制") + "</button>");

                        $("div#stopAutoTaskDiv").html("");
                        $("div#stopAutoTaskDiv").append(
                            "<button id='stopAutoTask' data-open=" + (value.agvsOpenAutoTask == 1 ? "true" : "false")
                            + ">" + (value.agvsOpenAutoTask == 1 ? "关闭自动任务功能" : "开启自动任务功能") + "</button>");
                    }
                });
            },
            error: function (e) {
            },
            timeout: 3000
        });
    }
    agvsinfo();
    setInterval(agvsinfo, 2000);
})(jQuery);
