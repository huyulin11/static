$(function () {
    sys = new Object();

    sys.getRole = function () {
        var role = '';
        jQuery.ajax({
            url: "/getRole.shtml",
            type: "post",
            dataType: "json",
            async: false,
            success: function (data) {
                role = data;
            }
        });
        return role;
    }
});
