$(function () {
    $("div#chargeMgr").delegate("button", "click", function () {
        $("div#chargeMgr button").attr("disabled", "disabled");
        setTimeout(() => {
            if (!confirm('是否确认执行该操作?')) { return; }
            doWork($(this).data("chargeid"), $(this).attr("id"));
        }, 500);
    });

    var doWork = function (chargeid, taskName) {
        jQuery.ajax({
            url: "/de/acs/wms/temp/test.shtml",
            type: "post",
            dataType: "json",
            data: {
                "type": taskName,
                "chargeid": chargeid,
                "testtype": "charge"
            },
            error: function (e) {
                layer.msg("数据中断，请刷新界面或重新登录！");
            },
            success: function (data) {
                alert(data);
                $("div#chargeMgr button").removeAttr("disabled");
            }
        });
    }
});
