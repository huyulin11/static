(function () {
	var reloadFlag = 0;
	var intervalVal;

	var init = function () {
		$(".allCtrlTr").delegate("button#PAUSE_USER", "click", function () {
			alert(agv.addCtrlTask(0, "PAUSE_USER"));
		});
		$(".allCtrlTr").delegate("button#manager", "click", function () {
			window.open('/manager.shtml');
		});
		$(".allCtrlTr").delegate("button#CONTINUE", "click", function () {
			alert(agv.addCtrlTask(0, "CONTINUE"));
		});

		$(".allCtrlTr").delegate("button#stopPI", "click", function () {
			var open = $(this).data("open");
			var tips = "";
			var opType = "";
			if (open) {
				tips = '是否确定关闭交通管制？';
				opType = "stopPI";
			} else {
				tips = '是否确定开启交通管制？';
				opType = "openPI";
			}
			if (window.confirm(tips)) {
				alert(agv.addCtrlTask(0, opType));
			}
		});

		$(".allCtrlTr").delegate("button#stopAutoTask", "click", function () {
			var open = $(this).data("open");
			var tips = "";
			var opType = "";
			if (open) {
				tips = '是否确定关闭自动任务功能？';
				opType = "stopAutoTask";
			} else {
				tips = '是否确定开启自动任务功能？';
				opType = "openAutoTask";
			}
			if (window.confirm(tips)) {
				alert(agv.addCtrlTask(0, opType));
			}
		});

		$(".allCtrlTr").delegate("button#sysLocation", "click", function () {
			window.open('/s/buss/acs/h/location.html');
		});

		//$("div#robotic").load("/s/buss/acs/h/lap.html");
	}

	init();
})(jQuery);
