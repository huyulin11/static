$(function () {
    var tasksiteStr = '<input type="text" class="form-control" placeholder="请输入站点编号" name="tasksite" id="tasksite">';
    var speedStr = '<input type="text" class="form-control" placeholder="请输入速度百分比" name="speed" id="speed">';
    var typeSelectStr = '<select id="type" name="type" data-key=1>'
        + '<option value ="1">停车</option>'
        + '<option value="2">左转</option>'
        + '<option value ="3">右转</option>'
        + '<option value ="4">变速</option>'
        + '</select > ';
    var cacheButtonStr = '<button id="DOCACHE">缓存指令</button>';
    var clearButtonStr = '<button id="CLEARCACHE">清空缓存指令</button>';
    var getFormStr = function (key) { return "<form id='ffff'>" + tasksiteStr + typeSelectStr + (type == '4' ? speedStr : "") + "</form>"; }

    $("div#tempAgvMgr").find("div#cacheDiv").append(getFormStr(null) + cacheButtonStr + clearButtonStr);

    $("div#tempAgvMgr").delegate("select#type", "change", function () {
        var type = $(this).val();
        if (type == '4') {
            $("div#tempAgvMgr").find("div#cacheDiv").find("form").append(speedStr);
        } else {
            $("div#tempAgvMgr").find("div#cacheDiv").find("form input#speed").remove();
        }
    });

    $("div#tempAgvMgr").delegate("button", "click", function () {
        var task = $(this).attr("id");
        var tasksite = $("input#tasksite").val();
        var type = $("#type").val();
        var speed = $("input#speed").val();
        if (task == 'cache' && (tasksite == "" || (type == '4' && speed == ""))) {
            alert("缓存数据有问题！");
            return;
        }
        if (!confirm('是否确认执行该操作?')) { return; }
        $("div#tempAgvMgr button").attr("disabled", "disabled");
        setTimeout(() => {
            doWork(task);
        }, 1000);
    });

    var doWork = function (taskName) {
        jQuery.ajax({
            url: "/de/acs/wms/temp/test.shtml",
            type: "post",
            dataType: "json",
            data: $("#ffff").serialize() + "&agvId=" + agvId + "&testtype=" + taskName,
            success: function (data) {
                alert(data);
                $("div#tempAgvMgr button").removeAttr("disabled");
            },
            error: function (e) {
                layer.msg("数据中断，请刷新界面或重新登录！");
                $("div#tempAgvMgr button").removeAttr("disabled");
            },
            timeout: 6000
        });
    }
});
