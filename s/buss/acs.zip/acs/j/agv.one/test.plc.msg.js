$(function () {
    var doWork = function (taskName) {
        jQuery.ajax({
            url: "/de/acs/wms/temp/plcmsg.shtml",
            type: "post",
            data: "agvId=" + agvId,
            dataType: "json",
            error: function (e) {
            },
            success: function (data) {
                $("div#plcMsg").html("");
                var lastMsg;
                for (var a of data) {
                    if (a != lastMsg) {
                        lastMsg = a;
                        $("div#plcMsg").append("<span>" + a + "</span><br/>");
                    }
                }
            }
        });
    }

    setInterval(() => {
        doWork();
    }, 2000);
});
