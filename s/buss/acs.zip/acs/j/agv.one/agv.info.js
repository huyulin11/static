var taskGroup = {};
var ctrlInfo = [];
var currentTask = new Array();
var agvId;

(function () {
	var agvinfo = function () {
		jQuery.ajax({
			url: "/agvinfo.shtml?agvId=" + agvId,
			type: "post",
			dataType: "json",
			success: refresh,
			complete: function (data) {
				$("#title").html(agvId + "号AGV控制");
				$(".black_overlay").hide();
			},
			error: function (e) {
			},
			timeout: 3000
		});
	}

	var allDisabled = function () {
		$(".oneCtrlTr button").attr("disabled", "true");
		$(".taskTr button").attr("disabled", "true");
	}

	var refresh = function (data) {
		allDisabled();
		var agvInfo, systemMsg, lastOverTask, latestCommand, systemWarning;

		agvInfo = data.agvInfo;
		if (!agvInfo) { return; }
		currentTask = data.currentTask;

		systemWarning = data.systemWarning;


		var movestatus = agvInfo.movestatus,
			sitestatus = agvInfo.sitestatus,
			taskstatus = agvInfo.taskstatus;

		latestCommand = data.latestCommand;

		if (systemWarning) {
			$("#warning").html(systemWarning);
		}

		allDisabled();

		if (movestatus == "PAUSE_USER" || movestatus == "PAUSE_SYS" || movestatus == "PAUSE_ERR") {
			$(".oneCtrlTr button#CONTINUE").removeAttr("disabled");
			return;
		} else {
			$(".oneCtrlTr button#PAUSE_USER").removeAttr("disabled");
		}

		if (sitestatus == "INIT" && taskstatus == "FREE") {
			$(".oneCtrlTr button#GOTO_CHARGE").removeAttr("disabled");
			return;
		}
		if (sitestatus == "CHARGING" && taskstatus == "GOTO_CHARGE") {
			$(".oneCtrlTr button#BACK_CHARGE").removeAttr("disabled");
		}
	}

	var init = function () {
		$(".oneCtrlTr").delegate("button", "click", function () {
			allDisabled();
			agv.addCtrlTask(agvId, $(this).attr("id"));
		});
		allDisabled();
		updateWidth();
		setInterval(agvinfo, 1500);
	}

	init();
})(jQuery);
