(function () {
    var oneAreaToHtmlTable = function (data) {
        var allAlloc = new Map();
        var maxColumn = 0;
        $.each(data, function (n, allocationInfo) {
            var rowAlloc = allAlloc.get(allocationInfo.rowId);
            if (!rowAlloc) {
                rowAlloc = new Map();
                rowAlloc.set("maxColumn", 0);
            }
            var colAlloc = rowAlloc.get(allocationInfo.colId);
            if (!colAlloc) {
                colAlloc = new Map();
                colAlloc.set("maxZ", 0);
            }
            colAlloc.set(allocationInfo.zId, allocationInfo);
            colAlloc.set("maxZ", colAlloc.get("maxZ") + 1);

            rowAlloc.set(allocationInfo.colId, colAlloc);

            rowAlloc.set("maxColumn", rowAlloc.get("maxColumn") + 1);
            allAlloc.set(allocationInfo.rowId, rowAlloc);
        });
        allAlloc.forEach(function (rowAlloc) {
            var tmpStr = "";
            rowAlloc.forEach(function (colAlloc) {
                if (typeof colAlloc == "number") {
                    return;
                }
                var tmpColStr = "";
                colAlloc.forEach(function (allocationInfo) {
                    if (typeof allocationInfo == "number") {
                        return;
                    }
                    if (allocationInfo.delflag == '0') {
                        var disabled = "";
                        var showInfo;
                        if (allocationInfo.text) {
                            showInfo = allocationInfo.text;
                        } else {
                            showInfo = "位" + allocationInfo.id;
                        }
                        var skuInfo = "<font style='font-size: 10px;'>" + ((allocationInfo.status != 1) ? sku.value(allocationInfo.skuId) : "空") + "</font>";
                        var weightNum = "<font style='font-weight: bolder;'>" + ((allocationInfo.status != 1) ? allocationInfo.num : "0") + "</font>";
                        showInfo = skuInfo + "<hr/>" + weightNum + "<hr/>" + showInfo;
                        tmpColStr = tmpColStr + "<tr><td><div><button "
                            + "data-id='" + allocationInfo.id + "'"
                            + " data-rowId='" + allocationInfo.rowId + "'"
                            + " data-colId='" + allocationInfo.colId + "'"
                            + " data-zId='" + allocationInfo.zId + "'"
                            + " data-text='" + allocationInfo.text + "'"
                            + " data-num='" + allocationInfo.num + "'"
                            + " data-status='" + allocationInfo.status + "'"
                            + " data-skuid='" + allocationInfo.skuId + "'"
                            + disabled + ">" + showInfo + "</button></div></td></tr>";
                    } else {
                        tmpColStr = tmpColStr + "<tr><td></td></tr>";
                    }
                    tmpColStr = tmpColStr;
                });
                tmpStr = tmpStr + "<td><table>" + tmpColStr + "</table></td>";
            });
            $("table.alloc").append(
                "<tr class='allocTr'>" + tmpStr + "</tr>");
        });
    }

    var initAlloc = function () {
        if (!$("#simple-2").is(":checked")) {
            return;
        }
        $(".black_overlay").show();
        $("table.alloc").html("");
        if (!areaId) {
            alert("对应区域的ID为空（areaId）");
            return;
        }
        jQuery.ajax({
            url: "/json/wms/getAllAllocationInfo.shtml?areaId=" + areaId,
            type: "post",
            dataType: "json",
            success: function (data) {
                oneAreaToHtmlTable(data);
            },
            complete: function (data) {
                setTimeout(function () {
                    $(".black_overlay").hide();
                }, 100);
            },
            error: function () {
                clearInterval(initAlloc);
            },
            timeout: 5000
        });
    }

    var initAllocColumn = function () {
        if (!areaId) {
            return;
        }
        jQuery.ajax({
            url: "/json/wms/getAllocColumn.shtml?areaId=" + areaId,
            type: "post",
            dataType: "json",
            success: function (data) {
                var tmpStr;
                $.each(data, function (n, column) {
                    var info;
                    if (column.allowedSkuId == 0 && column.allowedSkuType == 0) {
                        info = "通用";
                    } else {
                        if (column.allowedSkuId == -1) {
                            info = "空托盘";
                        }
                        if (column.allowedSkuId > 0) {
                            info = sku.value(column.allowedSkuId);
                        }
                        if (column.allowedSkuType > 0) {
                            info = (info ? (info + "<hr/>") : "") + sku.typevalue(column.allowedSkuType);
                        }
                    }
                    tmpStr = tmpStr + "<td><button class='inherit' "
                        + " data-colId='" + column.colId + "'"
                        + " data-allowedSkuId='" + column.allowedSkuId + "'"
                        + " data-allowedSkuType='" + column.allowedSkuType + "'"
                        + ">" + info + "</button></td>";
                });
                $("table.allocCol").append(
                    "<tr class='allocColTr'>" + tmpStr + "</tr>");
            },
            complete: function (data) {
            },
            error: function () {
            },
            timeout: 5000
        });
    }

    var areaId = 1;
    areaId = url.getQueryString("areaId");
    if (!areaId) {
        areaId = 1;
    }

    setTimeout(function () {
        initAllocColumn();
        initAlloc();
    }, 500);

    setTimeout(function () {
        $("table").each(function () {
            var tds = $(this).find("tr:first").find("td");
            tds.css("width", 100 / (tds.length) + "%");
        });
    }, 1000);

    setInterval(initAlloc, 3000);

    $("html").delegate("button.clr", "click", function () {
        if (!window.confirm('你确定要' + '清空第' + $(this).data("colid") + '列中，' + $(this).data("rowid") + '行' + $(this).data("zid") + '层及其后的所有货货位吗？')) {
            return;
        }

        jQuery.ajax({
            url: "/json/wms/clearAllocByColId.shtml?areaId=" + areaId + "&colId=" + $(this).data("colid") + "&minRowId=" + $(this).data("rowid") + "&minZId=" + $(this).data("zid"),
            type: "post",
            dataType: "json",
            success: function (data) {
                alert(data);
            },
            error: function () {
                alert("更新失败！");
            },
            timeout: 5000
        });
    });

    $("html").delegate("button.doChange", "click", function () {
        var num = $("input.doChange").val();
        var selectSkuId = $("div#doChangeDiv").find("select").val();
        var selectSkuName = sku.value(selectSkuId);
        var status = $(this).data("status");
        if (status == 2 && num == 0) {
            if (!window.confirm('当前货位状态为锁定状态，将数量修改为0将会将状态修改为空，且会将对应货位正在执行的任务强制结束掉，是否继续？')) {
                return;
            }
        } else {
            if (!window.confirm('更换品种将修改该区域该列所有的货位内容为对应品种，' + '你确定要' + '修改' + $(this).data("text")
                + '货位的品种种类为' + selectSkuName + '，库存数量为' + num + '吗？')) {
                return;
            }
        }

        var param = "allocItemId=" + $(this).data("id") + "&num=" + num + "&skuId=" + selectSkuId;

        jQuery.ajax({
            url: "/json/wms/doChangeNum.shtml?" + param,
            type: "post",
            dataType: "json",
            success: function (data) {
                alert(data);
            },
            error: function () {
                alert("更新失败！");
            },
            timeout: 5000
        });
    });

    var initTask = function (allocId) {
        var rtn = null;
        jQuery.ajax({
            url: "/getSingletaskByAllocId.shtml?allocId=" + allocId,
            type: "post",
            dataType: "json",
            async: false,
            success: function (data) {
                rtn = data;
            },
            timeout: 5000
        });
        return rtn;
    }

    $("table.alloc").delegate("button", "click", function () {
        var num = $(this).data("num");
        if (!num) { num = 0; }
        var taskStr = "";
        if (sys.getRole() == "admin") {
            var tasks = initTask($(this).data("id"));
            $.each(tasks, function (n, value) {
                taskStr = taskStr + "<tr><td><div><button class='tck doTask' id='" + value.taskCode + "'"
                    + " data-id='" + value.id + "' "
                    + " data-agvid='" + value.agvId + "' "
                    + " data-environmentId='" + value.environmentId + "' "
                    + " data-taskType='" + value.taskType + "' " + ">" + value.taskText
                    + "</button></div></td></tr>";
            });
        }
        var allowedskuid = $("table.allocCol tr.allocColTr").find("td button[data-colid='" + $(this).data("colid") + "']").data("allowedskuid");
        var allowedskutype = $("table.allocCol tr.allocColTr").find("td button[data-colid='" + $(this).data("colid") + "']").data("allowedskutype");
        var clrBtn = "<button class='clr tck' data-colid='" + $(this).data("colid") + "'" +
            " data-rowid='" + $(this).data("rowid") + "' data-zid='" + $(this).data("zid") + "'>清空该货位及以下货位货物</button>";
        var changeNumForm = "<div id='doChangeDiv'>修改当前货位库存<br/>种类为：" + sku.select($(this).data("skuid"), allowedskutype, allowedskuid) + "<br/>数量为：<input type='text' class='doChange' name='num' value='" + num + "'/></div>";
        var changeNumBtn = "<button class='tck doChange' data-id='" + $(this).data("id") + "' data-text='" + $(this).data("text") + "' data-status='" + $(this).data("status") + "'>确认</button>";
        layer.open({
            type: 1,
            title: $(this).data("text") + ($(this).data("status") != 1 ? ("-<font style='color:red;'>" + sku.value($(this).data("skuid")) + "</font>") : ""),
            skin: 'layui-layer-demo',
            closeBtn: 0,
            anim: 2,
            shade: 0.7,
            shadeClose: true,
            content: "<table><tr><td>" + changeNumForm + "</td></tr><tr><td>" + changeNumBtn + "</td></tr>" + "</table>"
            + "<hr>" + "<table>" + taskStr + "</table>" + "<hr>" + "<table>" + "<tr><td>" + clrBtn + "</td></tr></table>"
        });
    });

    $("html").delegate("button.doTask", "click", function () {
        var confirmMsg = "";
        if ($(this).html().endsWith('上料')) {
            confirmMsg = "上料需保证送料工序已经执行完毕，";
        } else if ($(this).html().endsWith('送光轴')) {
            confirmMsg = "送光轴需保证上料工序已经执行完毕，";
        } else if ($(this).html().endsWith('叫料')) {
            confirmMsg = "叫料需保证agv已回到起始位置，";
        } else if ($(this).html().endsWith('送料')) {
            confirmMsg = "送料需保证agv已回到起始位置，";
        }

        if (window.confirm(confirmMsg + '你确定要' + "执行:" + $(this).html() + '吗？')) {
            alert(agv.addTask($(this).data("agvid"), $(this).data("id")));
        } else {
            return;
        }
    });
})(jQuery);
