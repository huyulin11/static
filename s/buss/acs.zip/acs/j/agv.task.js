$(function () {
    agv = new Object();

    agv.addTask = function (agvId, taskid, whenError) {
        return addTask(agvId, taskid, whenError);
    }

    agv.addCtrlTask = function (agvId, taskid, whenError) {
        return addTask(agvId, taskid, whenError, "/json/op/addCtrlTask.shtml?agvId=" + agvId);
    }

    agv.addCtrlTaskRtnCode = function (agvId, taskid, whenError) {
        return addTaskRtnCode(agvId, taskid, whenError, "/json/op/addCtrlTask.shtml?agvId=" + agvId);
    }

    agv.addATaskBySystem = function (lapId) {
        return addTask(null, null, null, "/json/op/addATaskBySystem.shtml?lapId=" + lapId);
    }

    var addTask = function (agvId, taskid, whenError, urlInfo) {
        return _addTask(agvId, taskid, whenError, urlInfo).msg;
    }

    var addTaskRtnCode = function (agvId, taskid, whenError, urlInfo) {
        return _addTask(agvId, taskid, whenError, urlInfo).code;
    }

    var _addTask = function (agvId, taskid, whenError, urlInfo) {
        var rtnData;
        jQuery.ajax({
            url: (urlInfo) ? urlInfo : "/json/op/addTask.shtml?agvId=" + agvId,
            type: "post",
            data: {
                taskid: taskid
            },
            async: false,
            dataType: "json",
            success: function (data) {
                rtnData = data;
            },
            error: function (e) {
                layer.msg("数据中断，请刷新界面或重新登录！");
            },
            timeout: 5000
        });
        return rtnData;
    }
});
